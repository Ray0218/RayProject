//
//  RootViewController.h
//  LoopImage
//
//  Created by Ray on 14-10-24.
//  Copyright (c) 2014年 Ray. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@end
