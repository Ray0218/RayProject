//
//  RootViewController.m
//  LoopImage
//
//  Created by Ray on 14-10-24.
//  Copyright (c) 2014年 Ray. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()
{
    NSTimer *timer ;
    NSInteger  _curSpace ;
    UILabel* _label ;
}

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


#pragma mark -
#pragma mark 测试后台运行NSTimer

-(void)dealloc
{
    [timer invalidate];
}
-(void)testTimer{
   timer =[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(pvy_reloadTime) userInfo:nil repeats:YES] ;
    [timer fire];
    
}
-(void)pvy_reloadTime{

    NSLog(@"当前剩余 == %d",_curSpace) ;
    _label.text = [NSString stringWithFormat:@"%d",_curSpace] ;

    _curSpace -- ;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"滚动" ;
    _curSpace = 1000 ;
    [self testTimer];
    if ([[[UIDevice currentDevice]systemVersion]floatValue]>=7.0) {
        self.edgesForExtendedLayout = UIRectEdgeNone ;
    }
    
    _label= [[UILabel alloc]initWithFrame:CGRectMake(10, 80, 300, 60) ];
    _label.backgroundColor = [UIColor greenColor] ;
    _label.textAlignment = NSTextAlignmentCenter ;
    _label.text = [NSString stringWithFormat:@"%d",_curSpace] ;
    [self.view addSubview:_label];
    
  
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
