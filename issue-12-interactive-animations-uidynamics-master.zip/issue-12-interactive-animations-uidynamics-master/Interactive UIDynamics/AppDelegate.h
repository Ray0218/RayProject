//
//  AppDelegate.h
//  Interactive UIDynamics
//
//  Created by Florian on 21/04/14.
//  Copyright (c) 2014 Florian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end