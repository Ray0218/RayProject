//
//  ViewController.h
//  Layer中的应用
//
//  Created by Ray on 15/7/16.
//  Copyright (c) 2015年 Ray. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


static inline CGFloat DegreeToRadius(CGFloat degress){
    return  degress*M_PI/180 ;
}
