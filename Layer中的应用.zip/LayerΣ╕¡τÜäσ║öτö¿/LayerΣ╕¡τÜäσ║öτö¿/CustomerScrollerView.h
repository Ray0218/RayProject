//
//  CustomerScrollerView.h
//  Example
//
//  Created by Ray on 15/3/5.
//  Copyright (c) 2015年 Jonathan Tribouharet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomerScrollerView : UIView

@end
