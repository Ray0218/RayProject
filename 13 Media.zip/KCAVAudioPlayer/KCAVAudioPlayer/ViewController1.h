////
////  ViewController.h
////  KCAVAudioPlayer
////
////  Created by Kenshin Cui on 14/03/30.
////  Copyright (c) 2014年 cmjstudio. All rights reserved.
////
//
//#import <UIKit/UIKit.h>
//
//@interface ViewController : UIViewController
//
//
//@end
//
