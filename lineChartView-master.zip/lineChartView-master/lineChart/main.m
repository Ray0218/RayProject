//
//  main.m
//  lineChart
//
//  Created by pincution on 14-7-15.
//  Copyright (c) 2014年 pincution@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PNAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PNAppDelegate class]));
    }
}
