//
//  UINTViewController.h
//  InteractiveAnimations
//
//  Created by Chris Eidhof on 02.05.14.
//  Copyright (c) 2014 Unsigned Integer. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UINTAnimator;
@class UINTSpringAnimation;
@class POPSpringAnimation;


@interface UINTViewController : UIViewController

@end
