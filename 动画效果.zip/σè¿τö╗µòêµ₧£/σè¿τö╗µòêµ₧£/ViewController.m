//
//  ViewController.m
//  动画效果
//
//  Created by Ray on 15/3/6.
//  Copyright (c) 2015年 Ray. All rights reserved.
//

#import "ViewController.h"
#import "CustomerLayer.h"
#import "JTNumberScrollAnimatedView.h"
#import "JTSlideShadowAnimation.h"


@interface ViewController (){

    UIImageView *image1 ,*image2,*image3 ;
    UIImageView *dong1,*dong2,*dong3;
    
    UIView *_coverView ;
    
    UIImageView *imgArrowView ;
    CATextLayer *layers;
}
@property (strong, nonatomic) JTNumberScrollAnimatedView *animatedView;

@end

@implementation ViewController

-(void)pvt_testNumberScroller{

    self.animatedView = [[JTNumberScrollAnimatedView alloc]initWithFrame:CGRectMake(20, 100, 280, 100)];
    self.animatedView.textColor = [UIColor whiteColor];
    self.animatedView.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:30];
    self.animatedView.minLength = 3;
    self.animatedView.clipsToBounds = NO ;
    self.animatedView.isAscending = YES ;
    [self.view addSubview:self.animatedView];


}

#pragma mark- 测试图片Y轴和Z轴的倾斜
-(void)pvt_testYZ{

    UIImageView * imgView =[[UIImageView alloc]initWithFrame:CGRectMake(40, 400, 80, 80)];
    imgView.image = [UIImage imageNamed:@"1.jpg"] ;
    [self.view addSubview:imgView];
    
    CATransform3D transform = CATransform3DIdentity ;
    transform = CATransform3DRotate(transform, M_PI_4, 1, 0, 0) ;
    transform = CATransform3DRotate(transform, M_PI_4, 0, 1, 0) ;
    imgView.layer.transform = transform ;
    
    
    CAKeyframeAnimation *keyAnimation = [CAKeyframeAnimation animationWithKeyPath:@"sublayerTransform.rotation.x"] ;
    keyAnimation.values = [NSArray arrayWithObjects:[NSNumber numberWithFloat:M_PI_4*3],[NSNumber numberWithFloat:0], nil] ;
    keyAnimation.keyTimes = [NSArray arrayWithObjects:[NSNumber numberWithFloat:0.5],[NSNumber numberWithFloat:1],  nil] ;
    keyAnimation.duration = 4 ;
    keyAnimation.fillMode = kCAFillModeForwards ;
    keyAnimation.removedOnCompletion = NO ;
    [imgView.layer addAnimation:keyAnimation forKey:@"key"];
    

}

#pragma mark- 测试图片闪烁
-(void)pvt_testImageView{

    UIImageView * imgView =[[UIImageView alloc]initWithFrame:CGRectMake(40, 40, 80, 80)];
    [self.view addSubview:imgView];
    
    imgView.animationImages = [NSArray arrayWithObjects:[UIImage imageNamed:@"1.jpg"], [UIImage imageNamed:@"2.jpg"],[UIImage imageNamed:@"3.jpg"],[UIImage imageNamed:@"4.jpg"],[UIImage imageNamed:@"5.jpg"],[UIImage imageNamed:@"6.jpg"],[UIImage imageNamed:@"7.jpg"],nil] ;
    imgView.animationDuration = 2 ;
    imgView.animationRepeatCount = 1000 ;
    [imgView startAnimating];
    
    CATransform3D transform = CATransform3DIdentity;
    //z distance
    float distance = [[UIScreen mainScreen] bounds].size.height;
    float ratio    = [[UIScreen mainScreen] bounds].size.height/[[UIScreen mainScreen] bounds].size.height;
    transform.m34 = - ratio / distance;
    transform = CATransform3DRotate(transform, 60.0f * M_PI / 180.0f, 1.f, 0.0f, 0.0f);
    imgView.layer.transform = transform;
    imgView.layer.zPosition = distance * ratio;
    imgView.layer.position = CGPointMake([[UIScreen mainScreen] bounds].size.width/2, [[UIScreen mainScreen] bounds].size.height/3);

}

#pragma mark-色子动画
-(void)pvt_testBoBing{

    //逐个添加骰子
    UIImageView *_image1 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"1@2x.png"]];
    _image1.frame = CGRectMake(75.0, 315.0, 45.0, 45.0);
    image1 = _image1;
    [_coverView addSubview:_image1];
    UIImageView *_image2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"2@2x.png"]];
    _image2.frame = CGRectMake(135.0,315.0, 45.0, 45.0);
    image2 = _image2;
    [_coverView addSubview:_image2];
    UIImageView *_image3 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"3@2x.png"]];
    _image3.frame = CGRectMake(195.0, 315.0, 45.0, 45.0);
    image3 = _image3;
    [_coverView addSubview:_image3];
    
    //添加按钮
    UIButton *btn_bobing = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btn_bobing setTitle:@"点击" forState:UIControlStateNormal];
    [btn_bobing addTarget:self action:@selector(bobing)  forControlEvents:UIControlEventTouchUpInside];
    btn_bobing.frame = CGRectMake(140.0, 400.0, 80.0, 50.0);
    [self.view addSubview:btn_bobing];



}
- (void)bobing
{

    //隐藏初始位置的骰子
    image1.hidden = YES;
    image2.hidden = YES;
    image3.hidden = YES ;
    
    dong1.hidden = YES;
    dong2.hidden = YES;
    dong3.hidden = YES;
    //转动骰子的载入
    NSArray *myImages = [NSArray arrayWithObjects:
                         [UIImage imageNamed:@"dong1@2x.png"],
                         [UIImage imageNamed:@"dong2@2x.png"],
                         [UIImage imageNamed:@"dong3@2x.png"],nil];
    //骰子1的转动图片切换
    UIImageView *dong11 = [[UIImageView alloc]initWithFrame:CGRectMake(85.0, 315.0, 45.0, 45.0)];
    dong11.animationImages = myImages;
    dong11.animationDuration = 0.5;
    [dong11 startAnimating];
    [_coverView addSubview:dong11];
    dong1 = dong11;
    //骰子2的转动图片切换
    UIImageView *dong12 = [[UIImageView alloc]initWithFrame:CGRectMake(135.0, 315.0, 45.0, 45.0)];
    dong12.animationImages = myImages;
    dong12.animationDuration = 0.5;
    [dong12 startAnimating];
    [_coverView addSubview:dong12];
    dong2 = dong12;
    //骰子3的转动图片切换
    UIImageView *dong13 = [[UIImageView alloc] initWithFrame:CGRectMake(195.0, 315.0, 45.0, 45.0)];
    dong13.animationImages = myImages;
    dong13.animationDuration = 0.5;
    [dong13 startAnimating];
    [_coverView addSubview:dong13];
    dong3 = dong13;
    
    //******************旋转动画******************
    //设置动画
    CABasicAnimation *spin = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
    [spin setToValue:[NSNumber numberWithFloat:M_PI * 16.0]];
    [spin setDuration:4];

   
//    CALayer *imageLayer =[CALayer layer];
//    imageLayer.frame = dong11.bounds;
//    imageLayer.cornerRadius =10.0;
//    imageLayer.contents =(id)[UIImage imageNamed:@"dong1"].CGImage;
//    imageLayer.masksToBounds =YES;
//    [dong11.layer addSublayer:imageLayer];
//
////    sublayerTransform.
//    CABasicAnimation *anima = [CABasicAnimation animationWithKeyPath:@"sublayerTransform.translation.y"] ;
//    anima.duration = 3 ;
//    anima.toValue =[NSNumber numberWithFloat:100] ;
//    anima.fillMode = kCAFillModeForwards;
//    anima.removedOnCompletion = NO;

    //******************位置变化******************
    //骰子1的位置变化
    CGPoint p1 = CGPointMake(85.0,315.0);
    CGPoint p2 = CGPointMake(165.0, 300.0);
    CGPoint p3 = CGPointMake(240.0, 360.0);
    CGPoint p4 = CGPointMake(140.0, 400.0);
    NSArray *keypoint = [[NSArray alloc] initWithObjects:[NSValue valueWithCGPoint:p1],[NSValue valueWithCGPoint:p2],[NSValue valueWithCGPoint:p3],[NSValue valueWithCGPoint:p4], nil];
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    [animation setValues:keypoint];
    [animation setDuration:4.0];
    [animation setDelegate:self];
    [dong11.layer setPosition:CGPointMake(140.0, 400.0)];
    
    //骰子2的位置变化
    CGPoint p21 = CGPointMake(135.0, 315.0);
    CGPoint p22 = CGPointMake(160.0,420.0);
    CGPoint p23 = CGPointMake(85.0, 390.0);
    CGPoint p24 = CGPointMake(190.0, 375.0);
    NSArray *keypoint2 = [[NSArray alloc] initWithObjects:[NSValue valueWithCGPoint:p21],[NSValue valueWithCGPoint:p22],[NSValue valueWithCGPoint:p23],[NSValue valueWithCGPoint:p24], nil];
    CAKeyframeAnimation *animation2 = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    [animation2 setValues:keypoint2];
    [animation2 setDuration:4.0];
    [animation2 setDelegate:self];
    [dong12.layer setPosition:CGPointMake(190.0, 375.0)];
    //骰子3的位置变化
    CGPoint p31 = CGPointMake(195.0, 315.0);
    CGPoint p32 = CGPointMake(175.0, 295.0);
    CGPoint p33 = CGPointMake(140.0, 420.0);
    CGPoint p34 = CGPointMake(100.0, 330.0);
    NSArray *keypoint3 = [[NSArray alloc] initWithObjects:[NSValue valueWithCGPoint:p31],[NSValue valueWithCGPoint:p32],[NSValue valueWithCGPoint:p33],[NSValue valueWithCGPoint:p34], nil];
    CAKeyframeAnimation *animation3 = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    [animation3 setValues:keypoint3];
    [animation3 setDuration:4.0];
    [animation3 setDelegate:self];
    [dong13.layer setPosition:CGPointMake(100.0,330.0)];

    //******************动画组合******************
    //骰子1的动画组合
    CAAnimationGroup *animGroup = [CAAnimationGroup animation];
    animGroup.animations = [NSArray arrayWithObjects: animation,spin,nil];
    animGroup.duration = 4;
    [animGroup setDelegate:self];
    animGroup.fillMode = kCAFillModeForwards ;
    animGroup.removedOnCompletion = NO ;
    [[dong11 layer] addAnimation:animGroup forKey:@"position"];
    //骰子2的动画组合
    CAAnimationGroup *animGroup2 = [CAAnimationGroup animation];
    animGroup2.animations = [NSArray arrayWithObjects: animation2,spin,nil];
    animGroup2.duration = 4;
    [animGroup2 setDelegate:self];
    [[dong12 layer] addAnimation:animGroup2 forKey:@"position"];
    //骰子3的动画组合
    CAAnimationGroup *animGroup3 = [CAAnimationGroup animation];
    animGroup3.animations = [NSArray arrayWithObjects:animation3, spin,nil];
    animGroup3.duration = 4;
    [animGroup3 setDelegate:self];
    [[dong13 layer] addAnimation:animGroup3 forKey:@"position"];
    
    if (imgArrowView.layer.speed) {
        [self pauseLayer:imgArrowView.layer];
    }else{
        [self resumeLayer:imgArrowView.layer];
    }
    
}

-(void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{


    //停止骰子自身的转动
    [dong1 stopAnimating];
    [dong2 stopAnimating];
    [dong3 stopAnimating];

    
    //*************产生随机数，真正博饼**************
    srand((unsigned)time(0));  //不加这句每次产生的随机数不变
    //骰子1的结果
    int result1 = (rand() % 5) +1 ;  //产生1～6的数
    switch (result1) {
        case 1:dong1.image = [UIImage imageNamed:@"1@2x.png"];break;
        case 2:dong1.image = [UIImage imageNamed:@"2@2x.png"];break;
        case 3:dong1.image = [UIImage imageNamed:@"3@2x.png"];break;
        case 4:dong1.image = [UIImage imageNamed:@"4@2x.png"];break;
        case 5:dong1.image = [UIImage imageNamed:@"5@2x.png"];break;
        case 6:dong1.image = [UIImage imageNamed:@"6@2x.png"];break;
    }
    //骰子2的结果
    int result2 = (rand() % 5) +1 ;  //产生1～6的数
    switch (result2) {
        case 1:dong2.image = [UIImage imageNamed:@"1@2x.png"];break;
        case 2:dong2.image = [UIImage imageNamed:@"2@2x.png"];break;
        case 3:dong2.image = [UIImage imageNamed:@"3@2x.png"];break;
        case 4:dong2.image = [UIImage imageNamed:@"4@2x.png"];break;
        case 5:dong2.image = [UIImage imageNamed:@"5@2x.png"];break;
        case 6:dong2.image = [UIImage imageNamed:@"6@2x.png"];break;
    }
    //骰子3的结果
    int result3 = (rand() % 5) +1 ;  //产生1～6的数
    switch (result3) {
        case 1:dong3.image = [UIImage imageNamed:@"1@2x.png"];break;
        case 2:dong3.image = [UIImage imageNamed:@"2@2x.png"];break;
        case 3:dong3.image = [UIImage imageNamed:@"3@2x.png"];break;
        case 4:dong3.image = [UIImage imageNamed:@"4@2x.png"];break;
        case 5:dong3.image = [UIImage imageNamed:@"5@2x.png"];break;
        case 6:dong3.image = [UIImage imageNamed:@"6@2x.png"];break;
    }
    
    
    CABasicAnimation * animation = [CABasicAnimation animationWithKeyPath:@"transform.scale"] ;
    animation.toValue = [NSNumber numberWithFloat:0.5] ;
    animation.duration = 2 ;
    CAKeyframeAnimation *opcAnimation = [CAKeyframeAnimation animationWithKeyPath:@"opacity"] ;
    opcAnimation.values = [NSArray arrayWithObjects:[NSNumber numberWithFloat:1.0], [NSNumber numberWithFloat:0],nil] ;
    opcAnimation.keyTimes = [NSArray arrayWithObjects:
                             [NSNumber numberWithFloat:0.8],
                             [NSNumber numberWithFloat:1.0], nil];
    opcAnimation.duration = 2;
    
    CAAnimationGroup *group = [CAAnimationGroup animation] ;
    group.animations = @[animation,opcAnimation] ;
    group.duration = 2 ;
    group.autoreverses=NO;
    group.removedOnCompletion=NO;
    group.fillMode=kCAFillModeForwards;
    [dong1.layer addAnimation:group forKey:nil];
    [dong2.layer addAnimation:group forKey:nil];
    [dong3.layer addAnimation:group forKey:nil];
    
    
    
    CAKeyframeAnimation *keyAnimation = [CAKeyframeAnimation animationWithKeyPath:@"contents"] ;
    
    keyAnimation.values = [NSArray arrayWithObjects:(id)[UIImage imageNamed:@"1.jpg"].CGImage, (id)[UIImage imageNamed:@"7.jpg"].CGImage,nil] ;
    keyAnimation.keyTimes = [NSArray arrayWithObjects:
                             [NSNumber numberWithFloat:0.95],
                             [NSNumber numberWithFloat:1.0], nil];
    keyAnimation.duration = 4 ;
    keyAnimation.repeatCount = 1 ;
    keyAnimation.fillMode = kCAFillModeForwards ;
    keyAnimation.removedOnCompletion = NO ;
    
   
    layers.contents = (id)[UIImage imageNamed:@"7.jpg"].CGImage ;
    
    CATransform3D transfor = CATransform3DIdentity ;
    transfor.m34 = -1/500 ;
    
//    self.view.bounds.size.width
    
    
}


#pragma mark- 螺旋动画
-(void)pvt_createCircleAnimation{

    
    imgArrowView =[[UIImageView alloc]initWithFrame:CGRectMake(100, 250, 40, 40)];
    imgArrowView.image = [UIImage imageNamed:@"1@2x.png"] ;
    [self.view addSubview:imgArrowView];
    
//    CABasicAnimation  *baseAnimal = [CABasicAnimation animationWithKeyPath:@"zPosition"] ;
//    baseAnimal.fromValue = [NSNumber numberWithFloat:20.0] ;
//    baseAnimal.toValue = [NSNumber numberWithFloat:-600] ;

    CAKeyframeAnimation *keyAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"] ;
    UIBezierPath *path = [UIBezierPath bezierPath] ;
    [path moveToPoint:CGPointMake(310, 350)];
    
    float radius = 150 ;
        float endAngel = M_PI/20 ;
    
    [path addArcWithCenter:CGPointMake(160, 350) radius:radius startAngle:0 endAngle:endAngel clockwise:YES];

    for (int i=1; i<400; i++) {
        
        [path addArcWithCenter:CGPointMake(160, 350) radius:radius-i*0.25 startAngle:endAngel endAngle:endAngel+M_PI/20 clockwise:YES];
        endAngel+=M_PI/20 ;
    }
    keyAnimation.rotationMode = kCAAnimationRotateAuto ;
    keyAnimation.path = path.CGPath ;
 
    
    keyAnimation.duration = 10 ;
    keyAnimation.autoreverses = NO ;
    keyAnimation.removedOnCompletion = NO ;
    keyAnimation.fillMode =  kCAFillModeForwards ;
    keyAnimation.repeatCount = FLT_MAX ;

    
//    CAAnimationGroup *group = [CAAnimationGroup animation] ;
//    group.animations = @[baseAnimal, keyAnimation] ;
//    group.duration = 10 ;
//    group.autoreverses = NO ;
//    group.removedOnCompletion = NO ;
//    group.fillMode =  kCAFillModeForwards ;
//    group.repeatCount = FLT_MAX ;
    
    [imgArrowView.layer addAnimation:keyAnimation forKey:@"key"];
    
 
    CAShapeLayer *layer = [CAShapeLayer layer] ;
    layer.backgroundColor  = [UIColor greenColor].CGColor ;
    layer.fillColor = [UIColor clearColor].CGColor ;
    layer.path = path.CGPath ;
    layer.borderWidth = 3 ;
    layer.strokeColor = [UIColor brownColor].CGColor ;
    [self.view.layer addSublayer:layer];
    
    
//    self.view.layer.mask = ({
//        CALayer * la = [CALayer layer] ;
//        la.backgroundColor = [UIColor purpleColor].CGColor ;
//        la.frame = CGRectMake(0, 0, 40, 400) ;
//        la.opacity = 0.5 ;
//        la ;
//    
//    }) ;
    [path stroke];
}

#pragma mark- 动画的暂停
//暂停layer上面的动画
- (void)pauseLayer:(CALayer*)layer
{
    CFTimeInterval pausedTime = [layer convertTime:CACurrentMediaTime() fromLayer:nil];
    layer.speed = 0.0;
    layer.timeOffset = pausedTime;
}


//继续layer上面的动画
- (void)resumeLayer:(CALayer*)layer
{
    CFTimeInterval pausedTime = [layer timeOffset];
    layer.speed = 1.0;
    layer.timeOffset = 0.0;
    layer.beginTime = 0.0;
    CFTimeInterval timeSincePause = [layer convertTime:CACurrentMediaTime() fromLayer:nil] - pausedTime;
    layer.beginTime = timeSincePause;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = UIColorFromRGB(0xF8F8F8) ;
    
    
    
    _coverView = [[UIView alloc]initWithFrame:self.view.frame];
    _coverView.backgroundColor = [UIColor clearColor] ;
    _coverView.userInteractionEnabled = YES ;
    [self.view addSubview:_coverView] ;
    
    [self pvt_testNumberScroller];
    
    [self pvt_createCircleAnimation ] ;
    
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom] ;
    btn.frame = CGRectMake(0, 20, 80, 20) ;
    [btn setTitle:@"点击移动" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(pvt_click:) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = [UIColor blueColor] ;
    [self.view addSubview:btn];

    //测试图片闪烁
    [self pvt_testImageView];
    
    //测试图片的倾斜
    [self pvt_testYZ];

    UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake(10, 100, 80, 20)];
    lab.backgroundColor = [UIColor greenColor] ;
    lab.text = @"永久闪烁" ;
    [lab.layer addAnimation:[CustomerLayer opacityForever_Animation:0.3] forKey:@"opacity"];
    [self.view addSubview:lab];
    

    UILabel *lab2 = ({
        UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake(180, 64, 120, 20)];
        lab.backgroundColor = [UIColor greenColor] ;
        lab.text = @"闪烁一定次数" ;
        [lab.layer addAnimation:[CustomerLayer scale:@0.5 orgin:@2 durTimes:1 Rep:FLT_MAX] forKey:@"opacity"];
//
//        [lab.layer addAnimation:[CustomerLayer movepoint:CGPointMake(140, 400)]  forKey:@"transform.translation"];

        lab ;
    
    });
    
    [self.view addSubview:lab2];
    

    
  UILabel* lab3 =({
        UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake(100, 50, 100,100)];
        lab.backgroundColor = [UIColor clearColor] ;
        lab.userInteractionEnabled = YES ;
        
       layers = [CATextLayer layer] ;
        layers.bounds = lab.bounds ;
       
        //choose a font
        UIFont *font = [UIFont systemFontOfSize:15];
        //set layer font
        CFStringRef fontName = (__bridge CFStringRef)font.fontName;
        CGFontRef fontRef = CGFontCreateWithFontName(fontName);
        layers.font = fontRef;
        layers.fontSize = font.pointSize;
        CGFontRelease(fontRef);
        layers.alignmentMode = kCAAlignmentCenter ;
        layers.wrapped = YES;
        layers.string = @"旋转" ;
        layers.backgroundColor = [UIColor blueColor].CGColor ;
       CAAnimation * anim =[CustomerLayer rotation:0.15 degree:M_PI direction:6 repeatCount:31] ;
       anim.delegate =self ;
        [layers addAnimation:anim forKey:@"labeltransform"];

        layers.masksToBounds = YES ;
        layers.contents = (id)[UIImage imageNamed:@"1.jpg"].CGImage ;
        [lab.layer addSublayer:layers];
        lab ;
        
    });

    //测试色子运动
    [self pvt_testBoBing];
    
    //测试黑色阴影运动
    [self pvtTestShadow];
    
 }

-(void)pvtTestShadow{

    UIButton  *btn = [UIButton buttonWithType:UIButtonTypeCustom] ;
    [btn setTitle: @"Click to start or stop the animation" forState:UIControlStateNormal];
    btn.frame = CGRectMake(10, 480, 300, 40) ;
    btn.backgroundColor = [UIColor colorWithWhite:0.4 alpha:1] ;
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
   
    
    JTSlideShadowAnimation *shadowView = [JTSlideShadowAnimation new] ;
    shadowView.animatedView = btn ;
    shadowView.shadowWidth = 40 ;
    
    [self.view addSubview:btn];
    [shadowView start];
}



#pragma mark- 点击移动
-(void)pvt_click:(UIButton*)sender{

 
    [self.animatedView setValue:[NSNumber numberWithInt:(rand() % 5000)]];
    [self.animatedView startAnimation];
    
    //隐式动画
    
//    [UIView beginAnimations:nil context:NULL];
//    CGAffineTransform moveTransform = CGAffineTransformMakeTranslation(200, 300) ;
//    sender.layer.affineTransform= moveTransform ;
//    sender.layer.opacity = 1 ;
//    [UIView commitAnimations];
    
    
    //关键帧动画
    CAKeyframeAnimation *opAnim = [CAKeyframeAnimation animationWithKeyPath:@"opacity"];
    opAnim.duration = 6.0;
    opAnim.values =[NSArray arrayWithObjects:
                    [NSNumber numberWithFloat:0.25],
                    [NSNumber numberWithFloat:0.75],
                    [NSNumber numberWithFloat:1.0],
                    nil];
    opAnim.keyTimes = [NSArray arrayWithObjects:
                       [NSNumber numberWithFloat:0.0],
                       [NSNumber numberWithFloat:0.5],
                       [NSNumber numberWithFloat:1.0], nil];
    
    
    [sender.layer addAnimation:opAnim forKey:@"animateOpacity"];
    
    CGAffineTransform moveTransform = CGAffineTransformMakeTranslation(180, 200);
    CABasicAnimation *moveAnim = [CABasicAnimation animationWithKeyPath:@"transform"];
    moveAnim.duration = 6.0;
    moveAnim .delegate =self ;
    moveAnim.fillMode = kCAFillModeForwards ;
    moveAnim.removedOnCompletion = NO;//代表动画执行完毕后就从图层上移除，图形会恢复到动画执行前的状态。如果想让图层保持显示动画执行后的状态，那就设置为NO，不过还要设置fillMode为kCAFillModeForwards .
    moveAnim.toValue= [NSValue valueWithCATransform3D:
                       CATransform3DMakeAffineTransform(moveTransform)];
    [sender.layer addAnimation:moveAnim forKey:@"animateTransform"];
    

}



#pragma mark- 画圆
-(void)drawCircle{

    UIBezierPath *path = [[UIBezierPath alloc]init];
    
//    //画弧
//    [path moveToPoint:CGPointMake(0, 350)];
//    [path addQuadCurveToPoint:CGPointMake(320, 350) controlPoint:CGPointMake(160, 150)];
    
//    画圆
    [path addArcWithCenter:CGPointMake(20, 20) radius:40 startAngle:0 endAngle:2*M_PI clockwise:YES];
    
    
   CAShapeLayer* shapLayer = [CAShapeLayer layer] ;
    shapLayer.backgroundColor  = [UIColor clearColor].CGColor ;
    shapLayer.fillColor = [UIColor clearColor].CGColor ;
    shapLayer.path = path.CGPath ;
    shapLayer.borderWidth = 3 ;
    shapLayer.strokeColor = [UIColor brownColor].CGColor ;
    shapLayer.position = CGPointMake(140, 330) ;
    shapLayer.anchorPoint = CGPointMake(0.5, 0.5) ;
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    animation.duration =4 ;
    animation.fromValue = [NSNumber numberWithInt:0] ;
    animation.toValue = [NSNumber numberWithInt:1] ;
    animation.delegate = self ;
    [shapLayer addAnimation:animation forKey:@"key"];
    
    
    

    [self.view.layer addSublayer:shapLayer];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
