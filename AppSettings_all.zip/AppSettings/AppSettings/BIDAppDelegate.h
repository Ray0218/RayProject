//
//  BIDAppDelegate.h
//  AppSettings
//
//  Created by minglz on 13-5-2.
//  Copyright (c) 2013年 minglz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
